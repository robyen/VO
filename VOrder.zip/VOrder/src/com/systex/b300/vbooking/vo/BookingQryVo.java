package com.systex.b300.vbooking.vo;

public class BookingQryVo extends BookingVo {
	String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
