package com.systex.b300.vbooking.vo;

public class outCallBackVo {
	String outBoundSeq;
	String callType;
	String bookingId;
	String phoneNo;
	String dateTime;
	String result;
	public String getOutBoundSeq() {
		return outBoundSeq;
	}
	public void setOutBoundSeq(String outBoundSeq) {
		this.outBoundSeq = outBoundSeq;
	}
	public String getCallType() {
		return callType;
	}
	public void setCallType(String callType) {
		this.callType = callType;
	}
	public String getBookingId() {
		return bookingId;
	}
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getDateTime() {
		return dateTime;
	}
	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	
	
	
	

}
