package com.systex.b300.vbooking.vo.inline;

public class SystexConstant {
	public static final String COMPNAY_ID ="-LT5StKQwodH0qFcdSlk:inline-live-2a466";
	public static final String BRANCH_ID ="-LT5StN9tjJyrzSUyaCl";
	public static final String GROUP_ID ="systex";
	public static final String API_KEY ="Waskq4ERPzRFDbpKMptg3vwtdPsbXRvX";
	public static final String INLINE_BASE_URL = "https://api.inline.app/";
	public static final String INLINE_RESSERVATION_URL = INLINE_BASE_URL+"reservations/"+COMPNAY_ID+"/"+BRANCH_ID+"/";
	

	
}
