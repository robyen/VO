package com.systex.b300.vbooking.vo;

public class IVRReqData extends BaseVo {

	String callerId;
	String uid;
	String waveData;
	
	public String getCallerId() {
		return callerId;
	}
	public void setCallerId(String callerId) {
		this.callerId = callerId;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getWaveData() {
		return waveData;
	}
	public void setWaveData(String waveData) {
		this.waveData = waveData;
	}
	
	
}
